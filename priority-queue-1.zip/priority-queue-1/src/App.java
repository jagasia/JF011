import java.util.PriorityQueue;
import java.util.Queue;

public class App {

	public static void main(String[] args) {
		Queue<Employee> q=new PriorityQueue<Employee>();
		q.add(new Employee(11, "Rama", 22));
		q.add(new Employee(1, "John", 25));
		q.add(new Employee(5, "Adbul", 23));
		q.add(new Employee(9, "Suresh", 26));
		q.add(new Employee(7, "Dinesh", 20));
		
		for(int i=0;i<5;i++)
			System.out.println(q.poll());
	}

}
