import java.util.PriorityQueue;
import java.util.Queue;

public class Main {

	public static void main(String[] args) {
		Queue<Integer> q=new PriorityQueue<>();
		q.add(20);
		q.add(2);
		q.add(202);
		q.add(120);
		q.add(210);
		q.add(201);
		q.add(305);
		q.add(250);
		q.add(520);
		q.add(24);
		
//		System.out.println(q);
		for(int i=0;i<10;i++)
		{
			System.out.println(q.poll());
		}
		
		//do not use for-each loop. You will not see the effect of comparable or comparator
//		for(Integer i: q)
//			System.out.println(i);
	}

}
