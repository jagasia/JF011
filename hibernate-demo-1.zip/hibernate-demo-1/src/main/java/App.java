import com.cts.jf011.dao.StudentDaoImpl;
import com.cts.jf011.entity.Student;

public class App {

	public static void main(String[] args) {
		System.out.println("Hello world");
		StudentDaoImpl sdao=new StudentDaoImpl();
//		Student student = new Student();
//		student.setId(1);
//		student.setFirstName("Ram");
//		student.setLastName("Kumar");
//		
//		sdao.create(student);
//		sdao.update(student);
		sdao.delete(1);
		
		System.out.println("check database");
	}

}
