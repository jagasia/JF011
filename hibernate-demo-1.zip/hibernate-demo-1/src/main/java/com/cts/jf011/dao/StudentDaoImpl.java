package com.cts.jf011.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.jf011.entity.Student;

public class StudentDaoImpl {
	public void create(Student student) {
		Session session = getHibernateSession();
		Transaction tran = session.beginTransaction();
		
		session.persist(student);//		if there is an auto generated primary key, we should not give value to that
		System.out.println("Added");
		tran.commit();
		session.close();
	}

	
	public void read() {
		Session session = getHibernateSession();
		
		session.close();
	}
	public Student read(Integer id) {
		Session session = getHibernateSession();
		Student student = session.get(Student.class, id);		
		session.close();
		return student;
	}
	public void update(Student student) {
		Session session = getHibernateSession();
		Student st = read(student.getId());
		if(st==null)
		{
			System.out.println("Student not found for given id : "+student.getId());
		}else
		{
			st.setFirstName(student.getFirstName());
			st.setLastName(student.getLastName());
			Transaction tran = session.beginTransaction();
//			session.save(st);
			session.update(st);
			tran.commit();
			System.out.println("Updated");
		}
		session.close();
	}
	public void delete(Integer id) {
		Student st=read(id);
		if(st==null)
		{
			System.out.println("Student not found for given id : "+st.getId());
		}else
		{
			Session session=getHibernateSession();
			Transaction tran = session.beginTransaction();
			session.delete(st);
			System.out.println("Deleted");
			tran.commit();
			session.close();
		}
	}

	private Session getHibernateSession() {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
//		Session session = cfg.buildSessionFactory().openSession();
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		return session;
	}

}
