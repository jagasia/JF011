package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository cr;
	
	public Customer create(Customer customer) {
		return cr.save(customer);
	}
	public List<Customer> read() {
		return cr.findAll();
	}
	public Customer read(Integer id) {
		Optional<Customer> result = cr.findById(id);
		if(result.isPresent())
			return result.get();
		else
			return null;
				
	}
	
	public Customer update(Customer customer) {
		return cr.save(customer);
	}
	public boolean delete(Integer id) {
//		cr.deleteById(id);
		Customer c = read(id);
		if(c==null)
		{
			return false;
		}
		else
		{
			cr.delete(c);
			return true;
		}
	}
	
	public List<Customer> findCustomerByAddress(String address)
	{
		return cr.findCustomersByAddress(address);
	}
	
}
