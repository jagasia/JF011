package main;

import java.util.Date;

public class App {

	public static void main(String[] args) {
		//This is my comment.
//		System.out.println("Hello world");
		Date dt=new Date();
		dt=null;
		long result = dt.getTime();
	}

}
