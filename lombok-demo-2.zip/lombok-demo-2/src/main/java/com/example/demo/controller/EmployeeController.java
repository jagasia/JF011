package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Employee;

@Controller
public class EmployeeController {

	@GetMapping("/")
	@ResponseBody
	public String home()
	{
		Employee employee=new Employee(1, "Rama", "Krishna");
		System.out.println(employee.getFirstName());
		
		return "Hi";
	}
}
