package com.example.demol.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Branch;
import com.example.demo.repository.BranchRepository;

@Service
public class BranchService {
	@Autowired
	private BranchRepository br;
	
	public Branch create(Branch branch) {
		return br.save(branch);
	}
	public List<Branch> read() {
		return br.findAll();
	}
	public Branch read(String bid) {
//		return br.findById(bid).get();
		Optional<Branch> op = br.findById(bid);
		if(op.isPresent())
			return br.findById(bid).get();
		return null;
	}
	public Branch update(Branch branch) {
		return br.save(branch);
	}
	public Branch delete(String bid) {
		Branch branch = read(bid);
		if(branch==null)
			return null;
		br.delete(read(bid));
			return branch;
	}
	
}
