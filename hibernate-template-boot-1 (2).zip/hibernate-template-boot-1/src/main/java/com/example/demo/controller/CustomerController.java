package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entity.Customer;
import com.example.demo.service.CustomerService;

@Controller
//@RestController
public class CustomerController {
	@Autowired
	private CustomerService cs;
	
	@GetMapping("/")
	public ModelAndView home()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index");
		List<Customer> customerList = cs.read();
		System.out.println(customerList.size());
		mv.addObject("customers", customerList);
		mv.addObject("customer",new Customer());
		return mv;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/customer", params = "add")
//	@ResponseBody
	public ModelAndView addCustomer(Customer customer) {
		cs.create(customer);
		return home();
	}
	
	@GetMapping("/customer")
	public List<Customer> getAllCustomers()
	{
		return cs.read();
	}
	
	@RequestMapping(value = "select", method = RequestMethod.GET)
	public ModelAndView select(@RequestParam("id") Integer id)
	{
		Customer customer = cs.read(id);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index");
		List<Customer> customerList = cs.read();
		System.out.println(customerList.size());
		mv.addObject("customers", customerList);
		mv.addObject("customer",customer);
		return mv;
	}
	
	@GetMapping("/customer/{id}")
	public Customer findCustomerById(@PathVariable("id") Integer id)
	{
		return cs.read(id);
	}
	
//	@PutMapping("/customer")
	@RequestMapping(method = RequestMethod.POST, value = "/customer", params = "modify")
	public ModelAndView updateCustomer(Customer customer)
	{
		cs.update(customer);
		return home();
	}
	
//	@DeleteMapping("/customer/{id}")
//	@RequestMapping(method = RequestMethod.POST, value = "/customer", params = "delete")
	public ModelAndView deleteCustomer(@PathVariable("id") Integer id)
	{
		cs.delete(id);
		return home();
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/customer", params = "delete")
	public ModelAndView deleteCustomer(Customer customer) {
		cs.delete(customer.getId());
		return home();
	}
	
}
	
