package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.model.MyUser;
import com.example.demo.repository.UserRepository;

@Service
public class UserService implements UserDetailsService
{
	@Autowired
	private UserRepository ur;

	public MyUser findUserByUserName(String username)
	{
		Optional<MyUser> op = ur.findById(username);
		if(op.isPresent())
		{
			return op.get();
		}else
			return null;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		return findUserByUserName(username);
		Optional<MyUser> op = ur.findById(username);
		if(op.isPresent())
			return op.get();
		else
			return null;
	}
}
