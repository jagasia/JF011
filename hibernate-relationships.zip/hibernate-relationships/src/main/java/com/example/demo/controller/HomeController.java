package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.service.DepartmentService;

@Controller
public class HomeController {
	@Autowired
	private DepartmentService ds;

	@GetMapping("/")
	public ModelAndView home()
	{
		List<Department> departments = ds.read();
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index");
		mv.addObject("departments", departments);
		return mv;
	}
	
	@GetMapping("/findEmployees")
	@ResponseBody
	public List<Employee> findEmployees(   @RequestParam("id") String id)
	{
		System.out.println("Finding department for id: "+id);
		Department department = ds.read(Integer.parseInt(id));
		System.out.println(department.getName());
		System.out.println(department.getEmployees().size()+" employees found");
		return department.getEmployees();
	}
}
