package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.entity.Department;
import com.example.demo.service.DepartmentService;

@Controller
public class DepartmentController {
	@Autowired
	private DepartmentService ds;
	
	@GetMapping("/department")
	@ResponseBody
	public List<Department> getAllDepartments()
	{
		return ds.read();
	}
	
	@GetMapping("/department/{id}")
	@ResponseBody
	public Department findDepartmentById(@PathVariable("id") Integer id)
	{
		return ds.read(id);
	}
	
	@RequestMapping(value = "/department", method = RequestMethod.POST, params = "add")
	public void addDepartment(Department department)
	{
		ds.create(department);
	}
	
	@RequestMapping(value = "/department", method = RequestMethod.POST, params = "modify")
	public void modifyDepartment(Department department)
	{
		ds.update(department);
	}
	
	@RequestMapping(value = "/department", method = RequestMethod.POST, params = "delete")
	public void removeDepartment(Integer id)
	{
		ds.delete(id);
	}
}
