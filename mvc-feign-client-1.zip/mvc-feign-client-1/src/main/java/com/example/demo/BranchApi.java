package com.example.demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.Branch;

@FeignClient(value = "BranchApi", url = "http://localhost:8080")
public interface BranchApi {
	@PostMapping("/branch")
	public Branch addBranch(@RequestBody Branch branch);
	
	@GetMapping("/branch")
	public List<Branch> getAllBranches();
	
	@GetMapping("/branch/{bid}")
	public Branch findBranchById(@PathVariable("bid") String bid);
	
	@PutMapping("/branch")
	public Branch modifyBranch(@RequestBody Branch branch);
	
	@DeleteMapping("/branch/{bid}")
	public Branch removeBranch(@PathVariable("bid") String bid);
}
