package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.BranchApi;
import com.example.demo.model.Branch;

@Controller
public class BranchController {
	@Autowired
	private BranchApi ba;
	
	@GetMapping("/")
	public ModelAndView home()
	{
		//before i display the branch page, lets take all branches from rest api and put in model
		ModelAndView mv=new ModelAndView();
		mv.setViewName("branch");
		
		List<Branch> branches = ba.getAllBranches();
		
		mv.addObject("branches", branches);
		return mv;
	}
	
//	@PostMapping("")
	@RequestMapping(value = "/branch", method =RequestMethod.POST, params = "btnAdd")
	public ModelAndView addBranch(Branch branch) 
	{
//		System.out.println(branch);
		ba.addBranch(branch);
		return home();
	}
	
	@RequestMapping(value = "/branch", method =RequestMethod.POST, params = "btnModify")
	public ModelAndView modifyBranch(Branch branch) 
	{
//		System.out.println(branch);
		ba.modifyBranch(branch);
		return home();
	}
	
	@RequestMapping(value = "/branch", method =RequestMethod.POST, params = "btnDelete")
	public ModelAndView deleteBranch(Branch branch) 
	{
//		System.out.println(branch);
		ba.removeBranch(branch.getBid());
		return home();
	}
}
