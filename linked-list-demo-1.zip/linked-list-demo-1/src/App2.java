import java.util.Stack;

public class App2 {
	public static void main(String[] args) {
		
		Stack<String> stack=new Stack<>();
		stack.push("A");
		stack.push("B");
		stack.push("C");
		stack.push("D");
		stack.push("E");
		stack.push("F");
		stack.push("G");
		
		while(!stack.empty())
			System.out.println(stack.pop());
	}
}
