
public class JagSinglyLinkedList {
	private Node start;
	
	public JagSinglyLinkedList()
	{
		start=null;
	}
	public void addNode(String data)
	{
		Node newNode=new Node();
		newNode.setData(data);
		//if the linked list is empty, then add the new node at start. Otherwise, add at the end
		if(start==null)
		{
			start=newNode;
		}else
		{
			//find the last node. Which is last node? the node whose next is null is the last node.
			Node temp;
			temp=start;
			while(temp.getNext()!=null)
			{
				temp=temp.getNext();
			}
			temp.setNext(newNode);
		}
	}
	
	public void deleteNode(String data)
	{
		Node temp;
		//if list is empty, then nothing to delete
		if(start==null)
		{
			System.out.println("Nothing to delete");
			return;
		}		
		if(start.getData().equals(data))
		{
			start=start.getNext();
			return;
		}
		
		Node previous=start;
				
		for(temp=start;temp.getNext()!=null;previous=temp,temp=temp.getNext())
		{
			if(temp.getData().equals(data))
			{
				//deleting the last node
				if(temp.getNext()!=null)
				{
					//temp has next node
//					previous node's next should point to temp's next node
					previous.setNext(temp.getNext());				
				}
				temp=null;
				break;
			}			
		}
		
		//to remove last node
		if(temp!=null)
		{
			if(temp.getData().equals(data))
			{
				previous.setNext(null);
				temp=null;
			}
		}
	}
	
	public void traverse()
	{
		for(Node temp=start;temp!=null;temp=temp.getNext())
		{
			System.out.println(temp);
		}
	}
}
