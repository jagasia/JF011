
public class App {

	public static void main(String[] args) {
		JagSinglyLinkedList ll=new JagSinglyLinkedList();
		ll.addNode("India");
		ll.addNode("Australia");
		ll.addNode("Srilanka");
		ll.addNode("Japan");
		ll.addNode("USA");
		ll.addNode("England");
		ll.addNode("Canada");
		ll.addNode("Argentina");
		ll.addNode("Brazil");
		
		ll.deleteNode("Brazil");
		ll.traverse();
	}

}
