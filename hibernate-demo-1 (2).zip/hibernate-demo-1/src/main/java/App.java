import com.cts.jf011.dao.EmployeeDao;
import com.cts.jf011.dao.EmployeeDaoImpl;
import com.cts.jf011.dao.StudentDaoImpl;
import com.cts.jf011.entity.Employee;
import com.cts.jf011.entity.Student;

public class App {

	public static void main(String[] args) {
		System.out.println("Hello world");
//		StudentDaoImpl sdao=new StudentDaoImpl();
//		Student student = new Student();
//		student.setId(1);
//		student.setFirstName("Ram");
//		student.setLastName("Kumar");
//		
//		sdao.create(student);
//		sdao.update(student);
//		sdao.delete(1);
		
		EmployeeDao edao=new EmployeeDaoImpl();
		Employee emp=new Employee();
		
		emp.setId(1);
		emp.setName("Abraham");
		emp.setSalary(123456.0);
		
//		edao.create(emp);
//		edao.update(emp);
		edao.delete(1);
		
		System.out.println("check database");
	}

}
