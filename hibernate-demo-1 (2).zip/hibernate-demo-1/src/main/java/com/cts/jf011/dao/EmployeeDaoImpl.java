package com.cts.jf011.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.jf011.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	
	@Override
	public void create(Employee employee)
	{
		Session session = getHibernateSession();
		Transaction tran = session.beginTransaction();
		Serializable id = session.save(employee);
		System.out.println("Note down the id generated: "+id);
		tran.commit();
		session.close();
	}
	
	@Override
	public List<Employee> read()
	{
		Session session = getHibernateSession();
		Criteria criteria = session.createCriteria(Employee.class);
		List<Employee> result = criteria.list();
		session.close();
		return result;
	}
	
	@Override
	public Employee read(Integer id)
	{
		Session session = getHibernateSession();
		Employee employee = session.get(Employee.class, id);
		session.close();
		return employee;
	}
	
	@Override
	public void update(Employee employee)
	{
		Session session = getHibernateSession();
		Employee emp = read(employee.getId());
		if(emp==null)
		{
			System.out.println("There are no employees found for id: "+employee.getId());
			return;
		}
		Transaction tran = session.beginTransaction();
		emp.setName(employee.getName());
		emp.setSalary(employee.getSalary());
		session.update(emp);
		tran.commit();
		session.close();
	}
	
	@Override
	public void delete(Integer id)
	{
		Employee employee = read(id);
		if(employee!=null)
		{
			System.out.println("Found employee for id "+id+"  "+employee.toString());
			Session session = getHibernateSession();
			Transaction tran = session.beginTransaction();
			session.delete(employee);
			tran.commit();
			session.close();
		}else
		{
			System.out.println("Nothing to delete");
		}
	}
	
	
	
	
	
	private Session getHibernateSession() {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
//		Session session = cfg.buildSessionFactory().openSession();
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		return session;
	}
}
