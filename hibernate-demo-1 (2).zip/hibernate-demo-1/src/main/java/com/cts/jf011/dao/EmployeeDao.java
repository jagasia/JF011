package com.cts.jf011.dao;

import java.util.List;

import com.cts.jf011.entity.Employee;

public interface EmployeeDao {

	void create(Employee employee);

	List<Employee> read();

	Employee read(Integer id);

	void update(Employee employee);

	void delete(Integer id);

}