package com.example.demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.Branch;

@FeignClient(value = "BranchApi", url = "http://awsdemo3-env.eba-9ujmpzmb.ap-south-1.elasticbeanstalk.com/branch")
public interface BranchApi {

	@PostMapping("")
	public Branch addBranch(@RequestBody Branch branch);
	
	@GetMapping("")
	public List<Branch> getAllBranches();

	@GetMapping("/{bid}")
	public Branch findBranchById(@PathVariable("bid") String bid);

	@PutMapping("")
	public Branch modifyBranch(@RequestBody Branch branch);

	@DeleteMapping("/{bid}")
	public String removeBranch(@PathVariable("bid") String bid);
	
}
