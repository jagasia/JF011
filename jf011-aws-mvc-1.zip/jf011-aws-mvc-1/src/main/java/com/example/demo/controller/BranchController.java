package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.BranchApi;
import com.example.demo.model.Branch;

@Controller
public class BranchController {
	@Autowired
	private BranchApi ba;
	
	@GetMapping("/")
	public ModelAndView home(ModelMap model)
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("branch");
		
		List<Branch> branches = ba.getAllBranches();
		Branch branch = (Branch) model.getAttribute("branch");
		if(branch==null)
			branch=new Branch();
		mv.addObject("branch", branch);
		mv.addObject("branches", branches);
		return mv;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/branch", params = "btnAdd")
	public ModelAndView addBranch(Branch branch, ModelMap model) {
		ba.addBranch(branch);
		return home(model);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/branch", params = "btnModify")
	public ModelAndView modifyBranch(Branch branch, ModelMap model) {
		ba.modifyBranch(branch);
		return home(model);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/branch", params = "btnDelete")
	public ModelAndView deleteBranch(Branch branch, ModelMap model) {
		ba.removeBranch(branch.getBid());
		return home(model);
	}
	
	@GetMapping("/select")
	public ModelAndView select(@RequestParam("bid") String bid, ModelMap model)
	{
		Branch branch=ba.findBranchById(bid);
		model.addAttribute("branch", branch);
		return home(model);
	}
}
