package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Customer;
import com.example.demo.model.Product;
import com.example.demo.service.CustomerService;
import com.example.demo.service.ProductService;

@Controller
public class CustomerController {
	@Autowired
	private CustomerService cs;
	@Autowired
	private ProductService ps;
	
	@PostMapping("/customer")
	@ResponseBody
	public Customer create(@RequestBody Customer customer) {
		return cs.create(customer);
	}
	
	@GetMapping("/customer")
	@ResponseBody
	public List<Customer> read() {
		return cs.read();
	}
	
	@GetMapping("/customer/{id}")
	public Customer read(@PathVariable("id") Integer id) {
		return cs.read(id);
	}
	
	@PutMapping("/customer")
	@ResponseBody
	public Customer update(@RequestBody Customer customer) {
		return cs.update(customer);
	}
	
	@DeleteMapping("/customer/{id}")
	@ResponseBody
	public Customer delete(@PathVariable("id") Integer id) {
		Customer c=read(id);
		if(c!=null)		
			cs.delete(id);
		return c;
	}
	
	@PutMapping("/customer/product/{cid}/{pid}")
	@ResponseBody
	public String buyProduct(@PathVariable("cid") Integer cid, @PathVariable("pid") Integer pid)
	{
		Customer c=cs.read(cid);
		Product p=ps.read(pid);
		
		c.getProducts().add(p);
		cs.update(c);
		return "Check db";
	}
}
