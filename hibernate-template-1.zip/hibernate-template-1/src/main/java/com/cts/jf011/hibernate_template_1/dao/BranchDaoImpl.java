package com.cts.jf011.hibernate_template_1.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.cts.jf011.hibernate_template_1.entity.Branch;

public class BranchDaoImpl {
	private HibernateTemplate ht;
	
	
	
	public HibernateTemplate getHt() {
		return ht;
	}
	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	@Transactional
	public Serializable create(Branch branch) {
		return ht.save(branch);
	}
	public List<Branch> read() {
		return ht.loadAll(Branch.class);
	}
	public Branch read(Integer id) {
		return ht.get(Branch.class, id);
	}
	public void update(Branch branch) {
		ht.update(branch);
	}
	public void delete(Integer id) {
		ht.delete(read(id));
	}
	
	
}
