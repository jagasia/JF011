package com.cts.jf011.hibernate_template_1;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.jf011.hibernate_template_1.dao.BranchDaoImpl;
import com.cts.jf011.hibernate_template_1.entity.Branch;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        BranchDaoImpl bdao = (BranchDaoImpl) ctx.getBean("bdao");
        Branch branch=new Branch();
        branch.setBname("Old branch");
        branch.setBcity("Chennai");
        
        bdao.create(branch);
        System.out.println("Done");
        
    }
}
