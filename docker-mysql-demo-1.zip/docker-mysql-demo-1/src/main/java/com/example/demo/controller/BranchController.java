package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Branch;
import com.example.demo.service.BranchService;

@Controller
public class BranchController {
	@Autowired
	private BranchService bs;

	@GetMapping("/")
	public ModelAndView home()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index");
		
		List<Branch> branches = bs.read();
		mv.addObject("branches", branches);
		
		return mv;
	}
	
	@RequestMapping(value = "/branch", method = RequestMethod.POST, params = "btnAdd")
	public ModelAndView addBranch(Branch branch) {
		bs.create(branch);
		return home();
	}
	
	@RequestMapping(value = "/branch", method = RequestMethod.POST, params = "btnModify")
	public ModelAndView modifyBranch(Branch branch) {
		bs.update(branch);
		return home();
	}
	
	@RequestMapping(value = "/branch", method = RequestMethod.POST, params = "btnDelete")
	public ModelAndView deleteBranch(Branch branch) {
		bs.delete(branch.getBid());
		return home();
	}
	
	
}
