package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Customer;
import com.example.demo.service.CustomerService;

//@Controller
@RestController
public class CustomerController {
	@Autowired
	private CustomerService cs;
	
	@RequestMapping(method = RequestMethod.POST, value = "/customer")
//	@ResponseBody
	public Customer addCustomer(@RequestBody Customer customer) {
		return cs.create(customer);
	}
	
	@GetMapping("/customer")
	public List<Customer> getAllCustomers()
	{
		return cs.read();
	}
	
	@GetMapping("/customer/{id}")
	public Customer findCustomerById(@PathVariable("id") Integer id)
	{
		return cs.read(id);
	}
	
	@PutMapping("/customer")
	public Customer updateCustomer(@RequestBody Customer customer)
	{
		return cs.update(customer);
	}
	
	@DeleteMapping("/customer/{id}")
	public boolean deleteCustomer(@PathVariable("id") Integer id)
	{
		return cs.delete(id);
	}
	
}
	
